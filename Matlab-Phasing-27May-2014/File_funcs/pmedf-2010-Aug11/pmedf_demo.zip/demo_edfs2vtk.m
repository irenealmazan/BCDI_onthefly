%% Demo and test for and working with edfs2vtk.m
%% Convert a series of edf files to a vtk (volume) file.
%%
%% Author: Petr Mikulik
%% Version: August 2010
%% Previous versions: September 2004; February 2005


%% Choose your input edf file series:
%scan_files = tilde_expand('~/data/2004/sample1234/*0.edf.gz');
scan_files = 'rock_0deg_*.edf';
%scan_files = [getenv('HOME'), '/data/2004/wafer01/scan_0deg_0???.edf'];
%% Use every n-th file from the above list?
fevery = 4;

% Make the filelist:
files = wildcard2filelist(scan_files);
nfiles = length(files);
if nfiles==0
    fprintf('ERROR: No file from the series "%s" found!\n', scan_files);
    return;
end
if fevery>1
    files=files(1:fevery:nfiles);
end

%% Choose additional options:
%% Notes: Averaging -- to avoid too large final volume.
%%	  bin_z -- averaging images over rocking curve points.
clear opts;
opts.roi = [1,256; 1,128];
	% Choose pixel roi [xfrom,xto; yfrom,yto] from the original image.
	% Pixels are enumerated from 1; negative numbers are wrt opposite corner
	% (thus -1,-1 is the opposite corners); 0,0 is full stripe.
opts.binning = [2,2];
	% Averaging over pixel subareas.
opts.bin_z = 2;
	% Averaging over subsequent images.

if 1
    % Do you want to rescale the data range?
    opts.datatype = 'uchar';
    opts.zrange = [200,205];
    opts.zspan = 1;
end

% Print our options
opts

%% Output vtk file. Short name or large name?
outfile = sprintf('out.vtk');
%outfile = sprintf('%s-bin%dx%dx%d-roi_x_%d_%d_y_%d_%d.vtk', 'out', opts.binning,opts.bin_z,opts.roi);

%% Run the edfs to vtk conversion.
edfs2vtk(outfile, files, opts)

% eof demo_edfs2vtk.m
