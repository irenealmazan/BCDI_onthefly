%% Demo and test for the pmedf package:
%% show writing an edf file.
%%
%% Author: Petr Mikulik
%% Version: February 2005
%% Previous version: September 2002

% Make a matrix.
a=1./hilb(500);

% Make an empty header.
h = pmedf_emptyHeader;

% Write them:
h = pmedf_write('x.edf', h, a);
% Display the written file via zimg:
system('zimg x.edf | xv -');

% Change datatype for writing, then write and display:
h = pmedf_putInHeader(h, 'DataType', 'FloatValue')
h = pmedf_write('xfloat.edf', h, a);
system('zimg xfloat.edf | xv -');

% Change datatype for writing, then write and display:
h = pmedf_putInHeader(h, 'DataType', 'UnsignedShort');
h = pmedf_write('xushort.edf', h, a);
system('zimg xushort.edf | xv -');

% Write it as .edf.gz:
h = pmedf_write('yushort.edf.gz', h, a);
system('zimg yushort.edf.gz | xv -');
