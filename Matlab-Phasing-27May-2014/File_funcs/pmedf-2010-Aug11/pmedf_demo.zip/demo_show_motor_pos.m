%% Demo and test for the pmedf package:
%% Get position of a motor from edf header.
%%
%% Author: Petr Mikulik
%% Version: August 2010
%% Previous version: February 2005

myfile='a.edf';

if ~exist('h')
    [h, a] = pmedf_read(myfile);
end

% the motor to search for
%motor_name = 'Xomega';	% try a non-existing motor
%motor_name = 'omega';	% try an existing motor
motor_name = 'rtn';	% try an existing motor


% get string positions of all motors
motors_mne = pmedf_findInHeader(h, 'motor_mne', 'string');
motors_pos = pmedf_findInHeader(h, 'motor_pos', 'string');

omega_mnepos = pmedf_findMnePos(motors_mne, motor_name);
    % Find which word nb is the given motor name in the mnemonics

fprintf('Searched motor "%s" among:\n\t%s\n', motor_name, motors_mne);
fprintf('omega_mnepos=%g\n', omega_mnepos);

omega_pos = pmedf_findPos(motors_pos, omega_mnepos);
    % Find the motor position -- actually, the motor_mnepos'th word in the
    % given string.

fprintf('Position for motor %s is %g\n', motor_name, omega_pos);

% eof demo_show_motor_pos.m
